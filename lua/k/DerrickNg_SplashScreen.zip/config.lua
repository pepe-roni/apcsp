-- config.lua

application =
{
	content =
	{
		width = 750,
		height = 1200,
		scale = "zoomEven" 
	},
}